# Shoppers

It's a Ecommerce Store , a dynamic Web App. Here users can create their accounts & buy products of their choice. One can search their choice of product in respective categories. There is a separate section for Shopkeepers , so they can add, modify or delete products sold by them. Moreover Admins have control over the whole App. Admin can verify a shopkeeper, see details of customers as well as products.

#### Technologies Used:
  - Java JSP & Servlets (Backend)
  - HTML, CSS, JavaScript, JQuery, Bootstrap (Frontend)
  - MySQL DataBase
  - Apache Tomcat Server

#### Team Members:
* Ariesha Mittal (Backend & Database)
* Atin Kumar Garg (Frontend)  [Profile](https://github.com/AKG-0)
* Ayush Pandey (Frontend) [Profile](https://github.com/Ayush-Pandey1024)